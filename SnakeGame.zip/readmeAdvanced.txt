Welcome to Snake
Run the Jar fil to play the game.
All command line inputs are ignored, and board size must be set in the settings menu.

All difficulties have the same speed regardless of map size besides extreme.

We have experienced some differences between Mac and Windows computers:
1. The intended font is only shown on Windows
2. The game window on a Mac covers part of the window we are drawing on, as such the upper most row cannot always be seen

It is required that the Data.txt file is in the same directory as the jar-file.

Game by:
Thomas, Chris, Christian and Bastian
