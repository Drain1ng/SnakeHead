This project is 'simple snake'.
To launch the project find the jar file in your directory and type in the following command in the terminal:
java -jar SnakeBaseGame.jar n m
where n & m are integers from 5-100 inclusive that sets the dimensions of the board.
If the n & m are set to any other values than 5-100, then the game will not work and a non relevant error message will be given.

The project was made by:
Chris, Christian, Thomas and Bastian.